import React from 'react'

const CustomerBookinUpdate = () => {
  return (
    <div>CustomerBookinUpdate</div>
  )
}

export default CustomerBookinUpdate;