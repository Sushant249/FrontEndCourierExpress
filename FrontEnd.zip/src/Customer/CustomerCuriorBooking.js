

const CustomerCuriorBooking = () => {
  return (
    <div>CustomerCuriorBooking</div>
  )
}

export default CustomerCuriorBooking;