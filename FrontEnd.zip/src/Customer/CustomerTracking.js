import React from 'react'

const CustomerTracking = () => {
  return (
    <div>CustomerTracking</div>
  )
}

export default CustomerTracking;